import java.util.Scanner;

public class ex1{
    static public class Conta{
        private float saldo;
        private int conta;
        private int senha;

        public Conta(){}

        protected void setSaldo(float saldo){
            this.saldo += saldo;
        }
        public float getSaldo(){
            return saldo;
        }

        protected void setConta(int conta){
            this.conta= conta;
        }
        public int getConta(){
            return conta;            
        }

        protected void setSenha(int senha){
            this.senha=senha;
        }
        public int getSenha(){
            return senha;            
        }

    }

    static public class Caixa extends Conta{
        Conta c1= new Conta();
        int conta;
        int senha;

        public Caixa(int cc, int pass){
            conta = cc;
            senha = pass;
        }

        public boolean getAcesso(){
            if(c1.getConta()== conta && c1.getSenha() == senha){
                return true;
            }
            return false;
        }

        public void saque(float a){
            c1.setSaldo(-a);
        }

        public void deposito(float b){
            c1.setSaldo(b);
        }

        public float consulta(){
            return c1.getSaldo();
        }       

    }


    public class Principal{
        
        public static void main(String[] args) {
            Conta cc1= new Conta();
            cc1.setConta(102030);
            cc1.setSenha(12345);        

            Scanner entrada = new Scanner(System.in);
            System.out.print("Digite sua conta: ");
            int cc = entrada.nextInt();

            System.out.print("Digite sua senha: ");
            int pass= entrada.nextInt();

            Caixa operacao = new Caixa(cc, pass);

            if(operacao.getAcesso()==true){
                System.out.println("1- Saldo\n2-Saque\n3-Deposito\n4-sair ");
                int key= entrada.nextInt();
                do{
                    
                    switch (key) {
                        case 1:
                            operacao.consulta();                        
                            break;

                        case 2:
                            System.out.print("Digite o valor de saque: ");
                            int a= entrada.nextInt();
                            operacao.saque(a);
                            break;

                        case 3:
                            System.out.print("Digite o valor de deposito: ");
                            int b= entrada.nextInt();
                            operacao.deposito(b);
                            break;

                        default:
                            break;
                    }
                } while(key ==4);         
                
            }

        }

    }

}