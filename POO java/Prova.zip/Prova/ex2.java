public class ex2 {
    static public class Sinalizacao{
        private String nome;
        private String dataCompra;
        private String local;

        public void setSinalizacao(String nome, String dataCompra, String local ){
            this.nome=nome;
            this.dataCompra=dataCompra;
            this.local=local;
        }

        public Sinalizacao(String nome, String dataCompra, String local){
            setSinalizacao(nome, dataCompra, local);
        }
    }

    static public class Placa extends Sinalizacao{
        private String tipo;

        public void SetTipo(String tipo){
            this.tipo= tipo;
        }

        public Placa(){
            super(nome, dataCompra, local);
        }
            

    }

    static public class Semaforo extends Sinalizacao{
        private float temporizador;

        public void SetTemporizador(Float temporizador){
            this.temporizador= temporizador;
        }

        public Semaforo(float temp){
            SetTemporizador(temp);
        }
    }

    public class Principal{
        public static void main(String[] args) {
            Semaforo f1= new Semaforo(10);

            Placa p1 = new Placa("Tipomandrake");



        }
    }

    
}
